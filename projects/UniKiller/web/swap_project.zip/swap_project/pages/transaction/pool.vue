<template>
	<view class="main">
		<view style="padding: 20rpx;"><h3>Account address:</h3><view style="font-size:24upx">{{account}}</view></view>
		
		<view style="margin-bottom: 10rpx; margin-top: 10rpx; margin-left: 20rpx;">Fee：0.3%</view>

		<list>
			<!-- 注意事项: 不能使用 index 作为 key 的唯一标识 -->
			<view v-for="(item, index) in dataList" :key="item.id">
				<view style="padding: 30rpx; margin: 20rpx; border-radius: 20rpx;" class="oBorder">
					<view><span style="font-weight: 200;">token ：</span>{{item.token}}{{item.type}}</view>
					<view><span style="font-weight: 200;">value ：</span>${{item.value}}</view>
					<view><span style="font-weight: 200;">weight ：</span>{{item.weight}}</view>
					<view style="display: inline;">
						<button @click="toDeposit(item)" size="mini" style="margin: 10rpx;margin-top: 30rpx; background-color: #131313; color: #FFFFFF; margin-left: 230rpx;">
							Deposit</button>
						<button @click="toWithdrawal(item)" size="mini" style="margin: 10rpx;margin-top: 30rpx; background-color: #131313;color: #FFFFFF;">Withdrawal</button>
					</view>

				</view>
			</view>
		</list>
	</view>
</template>

<script>
	import list from '@/components/uni-list/uni-list.vue'
	let _this;
	export default {
		data() {
			return {
				account: '',
				totalToken: 1000,
				totalDolor: 1000,
				
				        
			
				dataList: [{
						id: "1",
						token: '1000000',
						type: " USDT",
						value: '1000000',
						weight: 100
					},
					{
						id: "2",
						token: '500',
						type: " ETH",
						value: '2000000',
						weight: 200
					},
					{
						id: "3",
						token: '10',
						type: " WBTC",
						value: '500000',
						weight: 50
					},
					{
						id: "5",
						token: '100000',
						type: " KNC",
						value: '300000',
						weight: 30
					},
					{
						id: "4",
						token: '600000',
						type: " USDC",
						value: '600000',
						weight: 60
					},
	
				]
			}
		},
		components: {
			list
		},
		created() {
			this.init(addr => {
				//得到相应的钱包地址
				console.log("账户地址，address:" + addr)
				this.account = addr;
			})
		},
		methods: {
			toDeposit(item) {
				console.log(item);
				uni.navigateTo({
					url: "/pages/transaction/deposit?token=" + item.token + "&value=" + item.value + "&type=" + item.type
				});
			},
			toWithdrawal(item) {
				console.log(item);
				uni.navigateTo({
					url: "/pages/transaction/withdrawal?token=" + this.item + "&value=" + item.value + "&type=" + item.type
				});
			},
			init(callback) {
				//判断用户是否安装MetaMask钱包插件
				if (typeof window.ethereum === "undefined") {
					//没安装MetaMask钱包进行弹框提示
					alert("Looks like you need a Dapp browser to get started.");
					alert("Consider installing MetaMask!");
				} else {
					//如果用户安装了MetaMask，你可以要求他们授权应用登录并获取其账号
					ethereum.enable()
						.catch(function(reason) {
							//如果用户拒绝了登录请求
							if (reason === "User rejected provider access") {
								// 用户拒绝登录后执行语句；
							} else {
								// 本不该执行到这里，但是真到这里了，说明发生了意外
								alert("There was an issue signing you in.");
							}
						}).then(function(accounts) {
							console.log('地址列表', accounts)
							//这里返回用户钱包地址
							callback(accounts[0]);
						});
				}
			},

		}
	}
</script>

<style>
	.main {
		display: flex;
		flex-direction: column;
		width: 100%;
		padding-top:4rpx;
		padding-right: 70rpx;
	}

	.card {
		padding: 10dp;
	}

	.oBorder {
		border: none;
		border-radius: 2.5rem;
		-webkit-box-shadow: 0 0 60rpx 0 rgba(43, 86, 112, .1);
		box-shadow: 0 0 60rpx 0 rgba(43, 86, 112, .1);
	}
</style>
